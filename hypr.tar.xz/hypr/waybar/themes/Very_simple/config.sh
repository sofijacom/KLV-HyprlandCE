#!/bin/bash
theme_name="Very_simple"
