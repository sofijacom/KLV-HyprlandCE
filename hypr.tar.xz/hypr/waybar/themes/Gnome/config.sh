#!/bin/bash
theme_name="Gnome"
