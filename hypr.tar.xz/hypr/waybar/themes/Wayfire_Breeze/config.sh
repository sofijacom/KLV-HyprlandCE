#!/bin/bash
theme_name="Wayfire_Breeze"
