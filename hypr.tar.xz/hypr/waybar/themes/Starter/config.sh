#!/bin/bash
theme_name="Starter"
