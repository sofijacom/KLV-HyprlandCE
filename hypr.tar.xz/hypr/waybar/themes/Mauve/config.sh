#!/bin/bash
theme_name="Mauve"
