#!/bin/bash
theme_name="RGB"
