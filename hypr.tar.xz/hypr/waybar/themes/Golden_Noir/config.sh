#!/bin/bash
theme_name="Golden_Noir"
