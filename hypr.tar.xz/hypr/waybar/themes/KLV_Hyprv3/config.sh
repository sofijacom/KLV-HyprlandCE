#!/bin/bash
theme_name="KLV_Hyprv3"
