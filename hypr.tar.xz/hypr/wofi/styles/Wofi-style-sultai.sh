#!/bin/bash
ln -sf "/home/spot/.config/hypr/wofi/styles/style-sultai.css" "/home/spot/.config/hypr/wofi/style.css"
