#!/bin/bash

ln -sf "/home/spot/.config/hypr/wofi/styles/style-darks" "/home/spot/.config/hypr/wofi/style.css"