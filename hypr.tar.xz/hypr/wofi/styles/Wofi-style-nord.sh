#!/bin/bash

ln -sf "/home/spot/.config/hypr/wofi/styles/style-nord.css" "/home/spot/.config/hypr/wofi/style.css"
