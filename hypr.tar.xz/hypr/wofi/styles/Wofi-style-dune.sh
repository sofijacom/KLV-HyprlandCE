#!/bin/bash

ln -sf "/home/spot/.config/hypr/wofi/styles/style-dune.css" "/home/spot/.config/hypr/wofi/style.css"