-- ╔══════════════════════════════════════════════════╗
-- ║               configs/keybinds.lua               ║
-- ╚══════════════════════════════════════════════════╝

-- Setting variables
local mainMod = "SUPER"
local scriptsDir = "/home/spot/.config/hypr/scripts"
local hyprDir = "/home/spot/.config/hypr"
local volume = scriptsDir .. "/volume"
local ScreenShot = scriptsDir .. "/ScreenShot.sh"
local files = "pcmanfm"
local browser = "firefox"
local term = "sakura"
-- local term = "kitty"
local backlight = scriptsDir .. "/brightness"
local kbacklight = scriptsDir .. "/brightness-kbd"
local lock = scriptsDir .. "/lockscreen"
local wallpaper_change = scriptsDir .. "/changeWallpaper"
local Web_Browser = scriptsDir .. "/Web-Browser.sh"
local themeswitcher = scriptsDir .. "/themeswitcher.sh"
local hint = scriptsDir .. "/keyhint"
local Wofi = scriptsDir .. "/Wofi.sh"
local WofiBig = scriptsDir .. "/WofiBig.sh"
local WofiEmoji = scriptsDir .. "/WofiEmoji.sh"
local WofiPower = scriptsDir .. "/WofiPower.sh"
local Clipboard = scriptsDir .. "/ClipManager.sh"
local DarkLight_Wofi = scriptsDir .. "/DarkLight-Wofi.sh"
local RainbowBorders = scriptsDir .. "/RainbowBorders.sh"
local Sunset = scriptsDir .. "/Sunset.sh"
local glassmorphism = scriptsDir .. "/glassmorphism"
local QuickEdit = scriptsDir .. "/QuickEdit.sh"
local toggleallfloat = scriptsDir .. "/toggleallfloat.sh"
local airplane_mode = scriptsDir .. "/airplane-mode.sh"
local rsclock = scriptsDir .. "/rsclock.sh"
local clear_cliphist = scriptsDir .. "/clear_cliphist.sh"
local record_script = scriptsDir .. "/record-script.sh"
local Wofi_record = scriptsDir .. "/Wofi-record.sh"
local portal_hyprland = scriptsDir .. "/portal-hyprland"
local matrix = scriptsDir .. "/matrix.sh"
local cava = scriptsDir .. "/cava.sh"
local conky = scriptsDir .. "/Conky.sh"

-- Notifications
hl.bind(mainMod .. " + S", hl.dsp.exec_cmd("swaync-client -t -sw"))

-- Conky
hl.bind("ALT + C", hl.dsp.exec_cmd(conky))

-- Cava (Console-based Audio Visualizer )
hl.bind(mainMod .. " + ALT + C", hl.dsp.exec_cmd(cava))
--bind = $mainMod, Y, exec, $term --class update -T update -e cava # f to cycle through foreground colors (term kitty)

-- Configure Network (nmtui)
hl.bind(mainMod .. " + SHIFT + N", hl.dsp.exec_cmd("sakura -x nmtui"))
-- 
hl.bind(mainMod .. " + SHIFT + F", hl.dsp.exec_cmd("sudo env WAYLAND_DISPLAY=\"$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY\"  XDG_RUNTIME_DIR=/user/run/0 dbus-run-session -- pcmanfm"))
--bind = $mainMod SHIFT,F, exec, sudo env WAYLAND_DISPLAY="$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY"  XDG_RUNTIME_DIR=/user/run/0 dbus-run-session -- thunar
hl.bind(mainMod .. " + SHIFT + G", hl.dsp.exec_cmd("sudo env WAYLAND_DISPLAY=\"$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY\"  XDG_RUNTIME_DIR=/user/run/0 dbus-run-session -- geany"))
hl.bind(mainMod .. " + N", hl.dsp.exec_cmd("sudo env WAYLAND_DISPLAY=\"$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY\" XDG_RUNTIME_DIR=/user/run/0 dbus-run-session -- gufw-pkexec"))
hl.bind(mainMod .. " + SHIFT + T", hl.dsp.exec_cmd("sudo env WAYLAND_DISPLAY=\"$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY\"  XDG_RUNTIME_DIR=/user/run/0 dbus-run-session -- sakura"))
hl.bind(mainMod .. " + CTRL + G", hl.dsp.exec_cmd("sudo env WAYLAND_DISPLAY=\"$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY\"  XDG_RUNTIME_DIR=/user/run/0 dbus-run-session -- gparted"))

-- Restart bar
hl.bind(mainMod .. " + SHIFT + Y", hl.dsp.exec_cmd("~/.config/hypr/scripts/startup"))

-- save on demand w_changes=RAM2 mode
hl.bind(mainMod .. " + SHIFT + P", hl.dsp.exec_cmd("sudo -HE sakura -x snapmergepuppy"))
hl.bind(mainMod .. " + SHIFT + X", hl.dsp.exec_cmd("~/.config/hypr/scripts/save2flash.sh"))

-- Example binds, see https://wiki.hyprland.org/Configuring/Binds/ for more
hl.bind(mainMod .. " + SHIFT + C", hl.dsp.exec_cmd("hyprctl reload"))
hl.bind(mainMod .. " + SHIFT + D", hl.dsp.exec_cmd(WofiBig))
hl.bind(mainMod .. " + ALT + J", hl.dsp.exec_cmd(WofiEmoji))
hl.bind(mainMod .. " + ALT + P", hl.dsp.exec_cmd(WofiPower))
hl.bind(mainMod .. " + D", hl.dsp.exec_cmd(Wofi))
hl.bind(mainMod .. " + SHIFT + Q", hl.dsp.window.close())
hl.bind(mainMod .. " + SHIFT + Space", hl.dsp.window.float({ action = "toggle" }))
hl.bind(mainMod .. " + SHIFT + M", hl.dsp.exec_cmd(matrix))
hl.bind(mainMod .. " + F", hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }))
hl.bind(mainMod .. " + Q", hl.dsp.window.close())
hl.bind(mainMod .. " + Return", hl.dsp.exec_cmd(term))
hl.bind(mainMod .. " + T", hl.dsp.exec_cmd(files))
hl.bind("CTRL + ALT + L", hl.dsp.exec_cmd(lock))
hl.bind(mainMod .. " + W", hl.dsp.exec_cmd(wallpaper_change))
hl.bind(mainMod .. " + CTRL + W", hl.dsp.exec_cmd(Web_Browser))
hl.bind(mainMod .. " + ALT + W", hl.dsp.exec_cmd(themeswitcher))
hl.bind(mainMod .. " + ALT + V", hl.dsp.exec_cmd(Clipboard))
hl.bind(mainMod .. " + ALT + R", hl.dsp.exec_cmd(DarkLight_Wofi))
hl.bind(mainMod .. " + ALT + B", hl.dsp.exec_cmd(RainbowBorders))
hl.bind(mainMod .. " + ALT + X", hl.dsp.exec_cmd(Sunset))
hl.bind(mainMod .. " + ALT + T", hl.dsp.exec_cmd(toggleallfloat))
hl.bind(mainMod .. " + ALT + E", hl.dsp.exec_cmd(QuickEdit))
hl.bind(mainMod .. " + ALT + G", hl.dsp.exec_cmd(glassmorphism))
hl.bind(mainMod .. " + ALT + K", hl.dsp.exec_cmd(rsclock))
hl.bind(mainMod .. " + C", hl.dsp.exec_cmd(clear_cliphist))
hl.bind(mainMod .. " + H", hl.dsp.exec_cmd(hint))
hl.bind(mainMod .. " + B", hl.dsp.exec_cmd("killall -SIGUSR1 waybar"))

-- Сolor selection pipette
hl.bind(mainMod .. " + SHIFT + O", hl.dsp.exec_cmd(term .. " --class hyprpicker --hold -e hyprpicker"))

hl.bind(mainMod .. " + CTRL + D", hl.dsp.layout("removemaster"))
hl.bind(mainMod .. " + Escape", hl.dsp.exec_cmd("hyprctl kill"))
hl.bind(mainMod .. " + I", hl.dsp.layout("addmaster"))
hl.bind(mainMod .. " + J", hl.dsp.layout("cyclenext"))
hl.bind(mainMod .. " + K", hl.dsp.layout("cycleprev"))
hl.bind(mainMod .. " + M", hl.dsp.layout("splitratio 0.3"))
hl.bind(mainMod .. " + P", hl.dsp.window.pseudo())
hl.bind(mainMod .. " + CTRL + Return", hl.dsp.layout("swapwithmaster"))
hl.bind(mainMod .. " + Space", hl.dsp.exec_cmd(scriptsDir .. "/changeLayout"))

-- Keyboard backlight
hl.bind("xf86MonBrightnessDown", hl.dsp.exec_cmd(backlight .. " --dec"))
hl.bind("xf86MonBrightnessUp", hl.dsp.exec_cmd(backlight .. " --inc"))

-- Volume and Media Control
hl.bind("xf86audioRaisevolume", hl.dsp.exec_cmd(volume .. " --inc"))
hl.bind("xf86audioLowervolume", hl.dsp.exec_cmd(volume .. " --dec"))
hl.bind("XF86AudioMicMute", hl.dsp.exec_cmd(volume .. " --toggle-mic"))
hl.bind("xF86AudioMute", hl.dsp.exec_cmd(volume .. " --toggle"))

hl.bind("xf86AudioPlay", hl.dsp.exec_cmd("playerctl play-pause"))
hl.bind("xf86AudioPause", hl.dsp.exec_cmd("playerctl play-pause"))
hl.bind("xf86AudioNext", hl.dsp.exec_cmd("playerctl next"))
hl.bind("xf86AudioPrev", hl.dsp.exec_cmd("playerctl previous"))

-- Wi-Fi airplane mode
hl.bind(mainMod .. " + ALT + Menu", hl.dsp.exec_cmd("$airplane-mode"))

-- triggered when external monitor is connected and closing lid
hl.bind("switch:Lid Switch", hl.dsp.exec_cmd("~/.config/hypr/scripts/switch-lid.sh"), { locked = true })

-- touchpad
hl.bind("Menu", hl.dsp.exec_cmd("~/.config/hypr/scripts/touchpad.sh"))

-- Screenshot keybindings NOTE: You may need to press Fn key as well
hl.bind(mainMod .. " + Print", hl.dsp.exec_cmd("~/.config/hypr/scripts/ScreenShot.sh --now"))
hl.bind(mainMod .. " + SHIFT + Print", hl.dsp.exec_cmd("~/.config/hypr/scripts/ScreenShot.sh --area"))
hl.bind(mainMod .. " + CTRL + Print", hl.dsp.exec_cmd("~/.config/hypr/scripts/ScreenShot.sh --in5"))
hl.bind(mainMod .. " + ALT + Print", hl.dsp.exec_cmd("~/.config/hypr/scripts/ScreenShot.sh --in10"))
hl.bind("ALT + Print", hl.dsp.exec_cmd("~/.config/hypr/scripts/ScreenShot.sh --active"))

-- screenshot with swappy (another screenshot tool)
hl.bind(mainMod .. " + SHIFT + S", hl.dsp.exec_cmd("grim -g \"$(slurp)\" - | swappy -f -"))

-- Screen video recording
hl.bind(mainMod .. " + SHIFT + W", hl.dsp.exec_cmd("~/.config/hypr/scripts/record-script.sh"))
hl.bind("ALT + W", hl.dsp.exec_cmd(Wofi_record))

-- effect
-- bind = ALT, F3, exec, xfce4-appfinder
hl.bind("F12", hl.dsp.exec_cmd("xfce4-terminal --drop-down"))

-- Resize
hl.bind(mainMod .. " + SHIFT + H", hl.dsp.window.resize({ x = -50, y = 0, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + L", hl.dsp.window.resize({ x = 50, y = 0, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + K", hl.dsp.window.resize({ x = 0, y = -50, relative = true }), { repeating = true })
hl.bind(mainMod .. " + SHIFT + J", hl.dsp.window.resize({ x = 0, y = 50, relative = true }), { repeating = true })

-- Move
hl.bind(mainMod .. " + CTRL + H", hl.dsp.window.move({ direction = "l" }))
hl.bind(mainMod .. " + CTRL + L", hl.dsp.window.move({ direction = "r" }))
hl.bind(mainMod .. " + CTRL + K", hl.dsp.window.move({ direction = "u" }))
hl.bind(mainMod .. " + CTRL + J", hl.dsp.window.move({ direction = "d" }))

-- Move focus with mainMod + arrow keys
hl.bind(mainMod .. " + left", hl.dsp.focus({ direction = "left" }))
hl.bind(mainMod .. " + right", hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod .. " + up", hl.dsp.focus({ direction = "up" }))
hl.bind(mainMod .. " + down", hl.dsp.focus({ direction = "down" }))

-- Special workspace
hl.bind(mainMod .. " + SHIFT + U", hl.dsp.window.move({ workspace = "special" }))
hl.bind(mainMod .. " + U", hl.dsp.workspace.toggle_special(""))

-- Switch workspaces with mainMod + [0-9]
hl.bind(mainMod .. " + 1", hl.dsp.focus({ workspace = 1 }))
hl.bind(mainMod .. " + 2", hl.dsp.focus({ workspace = 2 }))
hl.bind(mainMod .. " + 3", hl.dsp.focus({ workspace = 3 }))
hl.bind(mainMod .. " + 4", hl.dsp.focus({ workspace = 4 }))
hl.bind(mainMod .. " + 5", hl.dsp.focus({ workspace = 5 }))
hl.bind(mainMod .. " + 6", hl.dsp.focus({ workspace = 6 }))
hl.bind(mainMod .. " + 7", hl.dsp.focus({ workspace = 7 }))
hl.bind(mainMod .. " + 8", hl.dsp.focus({ workspace = 8 }))
hl.bind(mainMod .. " + 9", hl.dsp.focus({ workspace = 9 }))
hl.bind(mainMod .. " + 0", hl.dsp.focus({ workspace = 10 }))

-- Move active window and follow to workspace
hl.bind(mainMod .. " + CTRL + 1", hl.dsp.window.move({ workspace = 1 }))
hl.bind(mainMod .. " + CTRL + 2", hl.dsp.window.move({ workspace = 2 }))
hl.bind(mainMod .. " + CTRL + 3", hl.dsp.window.move({ workspace = 3 }))
hl.bind(mainMod .. " + CTRL + 4", hl.dsp.window.move({ workspace = 4 }))
hl.bind(mainMod .. " + CTRL + 5", hl.dsp.window.move({ workspace = 5 }))
hl.bind(mainMod .. " + CTRL + 6", hl.dsp.window.move({ workspace = 6 }))
hl.bind(mainMod .. " + CTRL + 7", hl.dsp.window.move({ workspace = 7 }))
hl.bind(mainMod .. " + CTRL + 8", hl.dsp.window.move({ workspace = 8 }))
hl.bind(mainMod .. " + CTRL + 9", hl.dsp.window.move({ workspace = 9 }))
hl.bind(mainMod .. " + CTRL + 0", hl.dsp.window.move({ workspace = 10 }))
hl.bind(mainMod .. " + CTRL + bracketleft", hl.dsp.window.move({ workspace = -1 }))
hl.bind(mainMod .. " + CTRL + bracketright", hl.dsp.window.move({ workspace = "+1" }))

-- Move active window to a workspace with mainMod + SHIFT + [0-9]
hl.bind(mainMod .. " + SHIFT + 1", hl.dsp.window.move({ workspace = 1, follow = false }))
hl.bind(mainMod .. " + SHIFT + 2", hl.dsp.window.move({ workspace = 2, follow = false }))
hl.bind(mainMod .. " + SHIFT + 3", hl.dsp.window.move({ workspace = 3, follow = false }))
hl.bind(mainMod .. " + SHIFT + 4", hl.dsp.window.move({ workspace = 4, follow = false }))
hl.bind(mainMod .. " + SHIFT + 5", hl.dsp.window.move({ workspace = 5, follow = false }))
hl.bind(mainMod .. " + SHIFT + 6", hl.dsp.window.move({ workspace = 6, follow = false }))
hl.bind(mainMod .. " + SHIFT + 7", hl.dsp.window.move({ workspace = 7, follow = false }))
hl.bind(mainMod .. " + SHIFT + 8", hl.dsp.window.move({ workspace = 8, follow = false }))
hl.bind(mainMod .. " + SHIFT + 9", hl.dsp.window.move({ workspace = 9, follow = false }))
hl.bind(mainMod .. " + SHIFT + 0", hl.dsp.window.move({ workspace = 10, follow = false }))
hl.bind(mainMod .. " + SHIFT + bracketleft", hl.dsp.window.move({ workspace = -1, follow = false }))
hl.bind(mainMod .. " + SHIFT + bracketright", hl.dsp.window.move({ workspace = "+1", follow = false }))

-- Scroll through existing workspaces with mainMod + scroll
hl.bind(mainMod .. " + mouse_down", hl.dsp.focus({ workspace = "e+1" }))
hl.bind(mainMod .. " + mouse_up", hl.dsp.focus({ workspace = "e-1" }))
hl.bind(mainMod .. " + period", hl.dsp.focus({ workspace = "e+1" }))
hl.bind(mainMod .. " + comma", hl.dsp.focus({ workspace = "e-1" }))

-- Move/resize windows with mainMod + LMB/RMB and dragging
hl.bind(mainMod .. " + mouse:272", hl.dsp.window.drag())
hl.bind(mainMod .. " + mouse:273", hl.dsp.window.resize())

hl.bind(mainMod .. " + G", hl.dsp.group.toggle())
hl.bind(mainMod .. " + tab", hl.dsp.focus({ workspace = "m+1" }))
hl.bind(mainMod .. " + SHIFT + tab", hl.dsp.focus({ workspace = "m-1" }))
hl.bind("ALT + tab", hl.dsp.focus({ workspace = "m+1" }))
hl.bind("ALT + SHIFT + tab", hl.dsp.focus({ workspace = "m-1" }))
