-- ╔══════════════════════════════════════════════════╗
-- ║               configs/monitors.lua               ║
-- ╚══════════════════════════════════════════════════╝

hl.monitor({
    output = "",
    mode = "preferred",
    position = "auto",
    scale = "1",
})

hl.monitor({
    output = "eDP-1",
    mode = "preferred",
    position = "auto",
    scale = "1",
})

hl.monitor({
    output = "DP-3",
    mode = "preferred",
    position = "0x0",
    scale = "1",
})

hl.monitor({
    output = "HDMI-A-1",
    mode = "preferred",
    position = "auto",
    scale = "1",
})

-- ############################# QEMU ###############################

--hl.monitor({
--    output = "Virtual-1",
--    mode = "1920x1080@60",
--    position = "auto",
--    scale = "1",
--})

-- Example :
--hl.monitor({
--    output = "eDP-1",
--    mode = "2560x1440@165",
--    position = "0x0",
--    scale = "1",
--})

--hl.workspace_rule({
--    workspace = "HDMI-A-1",
--})

--hl.monitor({
--    output = "HDMI-A-1",
--    mode = "2560x1440@144",
--    position = "0x0",
--    scale = "1",
--    mirror = "eDP-1",
--})

--hl.workspace_rule({
--    workspace = "HDMI-A-2",
--})

--hl.monitor({
--    output = "eDP-1",
--    transform = 0,
--})

--hl.monitor({
--    output = "eDP-1",
--    addreserved = { top = 10, bottom = 10, left = 10, right = 49 },
--})

--hl.workspace_rule({
--    workspace = "eDP-1",
--})


