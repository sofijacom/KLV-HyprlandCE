-- ╔══════════════════════════════════════════════════╗
-- ║               configs/exec.lua                   ║
-- ╚══════════════════════════════════════════════════╝

local scriptsDir = "/home/spot/.config/hypr/scripts"
local themesDir = "/home/spot/.config/hypr/themes"
local home = os.getenv("HOME")

-- wallpaper stuff
-- hl.exec_cmd("swaybg -m fill -i " .. home .. "/Pictures/wallpapers/0107.jpg")
-- hl.exec_cmd("swww query || swww init && swww img " .. home .. "/Pictures/wallpapers/Dynamic-Wallpapers/Dark/Beach_dark.jpg")

-- Startup:
hl.on("hyprland.start", function()
    hl.exec_cmd("dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")
   -- hl.exec_cmd("systemctl --user import-environment WAYLAND_DISPLAY XDG_CURRENT_DESKTOP")    
    hl.exec_cmd(scriptsDir .. "/startup")
    hl.exec_cmd("sway-audio-idle-inhibit")
   -- hl.exec_cmd("blueman-applet &")
    hl.exec_cmd("waypaper --restore")
    hl.exec_cmd("hypridle")
    hl.exec_cmd("swaync &")
   -- hl.exec_cmd(scriptsDir .. "/portal-hyprland")
    hl.exec_cmd("wl-paste --type text --watch cliphist store")
    hl.exec_cmd("wl-paste --type image --watch cliphist store")
   -- hl.exec_cmd(scriptsDir .. "/RainbowBorders.sh")
   
   -- wlsunset - for automatic gamma adjustment. Default is 19:00 to 07:00 (7pm to 7am). Edit Sunset.sh accordingly
   -- hl.exec_cmd(scriptsDir .. "/Sunset.sh")

   -- Catpuccin Themes:
   -- To enable another theme, uncomment the desired line below and comment the rest
    hl.exec_cmd("hyprctl dispatch source " .. themesDir .. "/macchiato.conf")
   -- hl.exec_cmd("hyprctl dispatch source " .. themesDir .. "/frappe.conf")
   -- hl.exec_cmd("hyprctl dispatch source " .. themesDir .. "/latte.conf")
   -- hl.exec_cmd("hyprctl dispatch source " .. themesDir .. "/mocha.conf")


end)
