-- ╔══════════════════════════════════════════════════╗
-- ║               configs/autostart.lua              ║
-- ╚══════════════════════════════════════════════════╝

hl.on("hyprland.start", function()
    -- Initialize swww
    hl.exec_cmd("swww query || swww init")

    -- Start PipeWire
    hl.exec_cmd("pipewire &")

    -- Start PipeWire-pulse
    hl.exec_cmd("pipewire-pulse &")

    -- Run startup script
    hl.exec_cmd("/usr/local/bin/start-up")
end)

