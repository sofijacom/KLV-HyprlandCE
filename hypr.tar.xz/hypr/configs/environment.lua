-- ╔══════════════════════════════════════════════════╗
-- ║               configs/environments.lua           ║
-- ╚══════════════════════════════════════════════════╝

hl.env("XDG_CURRENT_DESKTOP", "Hyprland")
hl.env("XDG_SESSION_TYPE", "wayland")
hl.env("XDG_SESSION_DESKTOP", "Hyprland")
hl.env("XCURSOR_SIZE", "21")
hl.env("QT_QPA_PLATFORMTHEME", "qt5ct")
-- hl.env("QT_QPA_PLATFORMTHEME", "qt6ct")
-- hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("QT_STYLE_OVERRIDE", "kvantum")
hl.env("QT_WAYLAND_DISABLE_WINDOWDECORATION", "1")
hl.env("QT_AUTO_SCREEN_SCALE_FACTOR", "1")
hl.env("GDK_BACKEND", "wayland,x11")
hl.env("CLUTTER_BACKEND", "wayland")
hl.env("_JAVA_AWT_WM_NONREPARENTING", "1")

-- hl.env("GTK_THEME", "Adwaita:dark")
-- hl.env("HYPRCURSOR_THEME", "rose-pine-hyprcursor")
-- hl.env("HYPRCURSOR_THEME", "catppuccin-macchiato-mauve-cursors")
-- hl.env("HYPRCURSOR_THEME", "catppuccin-macchiato-blue-cursors")
hl.env("HYPRCURSOR_THEME", "catppuccin-macchiato-dark-cursors")
-- hl.env("HYPRCURSOR_THEME", "catppuccin-macchiato-light-cursors")
hl.env("HYPRCURSOR_SIZE", "21")

-- vulkan
-- hl.env("WLR_RENDERER", "vulkan")

-- firefox
-- hl.env("MOZ_ENABLE_WAYLAND", "1")

-- NVIDIA 
-- This is from Hyprland Wiki but my Hyprland keeps crashing when I enabled this variables

-- hl.env("WLR_NO_HARDWARE_CURSORS", "1")
-- hl.env("LIBVA_DRIVER_NAME", "nvidia")
-- hl.env("__GLX_VENDOR_LIBRARY_NAME", "nvidia")
-- hl.env("GBM_BACKEND", "nvidia-drm")

-- hl.env("__NV_PRIME_RENDER_OFFLOAD", "1")
-- hl.env("__VK_LAYER_NV_optimus", "NVIDIA_only")
-- hl.env("WLR_DRM_NO_ATOMIC", "1")
-- hl.env("NVD_BACKEND", "direct")
