-- ╔══════════════════════════════════════════════════╗
-- ║               configs/window_rules.lua           ║
-- ╚══════════════════════════════════════════════════╝

--################
--## POSITION ###
--##############

hl.window_rule({
    name = "windowrule-2",
    match = {
        class = "^(nm-connection-editor|nm-applet|blueman-manager)$",
    },
    float = true,
})

hl.window_rule({
    name = "windowrule-3",
    match = {
        class = "^(swayimg|vlc|Viewnior|pavucontrol|kvantummanager)$",
    },
    float = true,
})

hl.window_rule({
    name = "windowrule-4",
    match = {
        class = "^(nwg-look|qt5ct|qt6ct|mpv|galculator|unetbootin)$",
    },
    float = true,
})

hl.window_rule({
    name = "windowrule-5",
    match = {
        class = "^(zoom|xarchiver|waypaper|usbimager|octoxbps)$",
    },
    float = true,
})

hl.window_rule({
    name = "windowrule-6",
    match = {
        class = "^(wdisplays|font-viewer|yad|nwg-displays|azote|lxtask|smplayer)$",
    },
    float = true,
})

hl.window_rule({
    name = "windowrule-7",
    match = {
        class = "^(nwg-look)$",
    },
    float = true,
    opacity = "0.80 0.80",
})

hl.window_rule({
    name = "windowrule-8",
    match = {
        class = "^(audacious)$",
    },
    float = true,
    workspace = "9",
})

hl.window_rule({
    name = "windowrule-9",
    match = {
        title = "^(Picture-in-Picture)$",
    },
    float = true,
})

--##################
--##  maximize ###
--################

hl.window_rule({
    name = "windowrule-10",
    match = {
        class = ".*",
    },
    suppress_event = "maximize",
})

--##################
--##  Workspace ###
--################

hl.window_rule({
    match = {
        class = "^(Firefox)$",
    },
    workspace = "1",
})

hl.window_rule({
    match = {
        class = "^(microsoft-edge)$",
    },
    workspace = "2",
})

hl.window_rule({
    match = {
        class = "^(chromium)$",
    },
    workspace = "3",
})

hl.window_rule({
    match = {
        class = "^(com.obsproject.Studio)$",
    },
    workspace = "4",
})

hl.window_rule({
    match = {
        class = "^(Steam)$",
        title = "^(Steam)$",
    },
    workspace = "5",
})

hl.window_rule({
    match = {
        class = "^(lutris)$",
    },
    workspace = "5",
})

hl.window_rule({
    match = {
        class = "^(virt-manager)$",
    },
    workspace = "6",
})

hl.window_rule({
    match = {
        class = "^(discord)$",
    },
    workspace = "7",
})

-- windowrule = workspace 8, match:class ^(pcmanfm)$
hl.window_rule({
    match = {
        class = "^(audacious)$",
    },
    workspace = "9",
})

--###############
--## Opacity ###
--#############

hl.window_rule({
    match = {
        class = "pcmanfm",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "sakura",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "Firefox",
    },
    opacity = "0.9 0.9",
})

hl.window_rule({
    match = {
        class = "Brave-browser",
    },
    opacity = "0.9 0.9",
})

hl.window_rule({
    match = {
        class = "Steam",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "steamwebhelper",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "Spotify",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "Code",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "code-url-handler",
    },
    opacity = "0.8 0.8",
})

-- windowrule = opacity 0.8 0.8, match:class kitty

hl.window_rule({
    match = {
        class = "nwg-look",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "qt5ct",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "lxtask",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "kvantummanager",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "yad",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "pavucontrol",
    },
    opacity = "0.8 0.7",
})

hl.window_rule({
    match = {
        class = "blueman-manager",
    },
    opacity = "0.8 0.7",
})

hl.window_rule({
    match = {
        class = "nm-applet",
    },
    opacity = "0.8 0.7",
})

hl.window_rule({
    match = {
        class = "nm-connection-editor",
    },
    opacity = "0.8 0.7",
})

hl.window_rule({
    match = {
        class = "thunar",
    },
    opacity = "0.8 0.8",
})

-- windowrule = opacity 0.8 0.8, match:class foot
-- windowrule = opacity 0.8 0.8, match:class wofi
-- windowrule = opacity 0.8 0.8, match:class rofi

hl.window_rule({
    match = {
        class = "geany",
    },
    opacity = "0.9 0.9",
})

hl.window_rule({
    match = {
        class = "codium-url-handler",
    },
    opacity = "0.9 0.9",
})

hl.window_rule({
    match = {
        class = "VSCodium",
    },
    opacity = "0.9 0.9",
})

hl.window_rule({
    match = {
        class = "XTerm",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        class = "UXTerm",
    },
    opacity = "0.8 0.8",
})

hl.window_rule({
    match = {
        float = true,
    },
    opacity = "0.7 0.7",
})

-- windowrule = opacity 0.5 0.5, match:float true

--############
--## Size ###
--##########

-- for ttyclock / rsclock
hl.window_rule({
    name = "windowrule-46",
    match = {
        class = "^(clock)$",
        title = "^(clock)$",
    },
    float = true,
    size = "(monitor_w*0.37) (monitor_h*0.27)",
    center = true,
})

-- windowrule {
--  name = windowrule-47
--  size = 400 550
--  center = on
--  float = on
--  match:class = (Rofi)
-- }

--#################
--## layerrule ###
--###############

-- layerrule {
--  name = layerrule-1
--  ignore_alpha = 0
--  match:namespace = swaync-control-center
-- }

-- layerrule {
--  name = layerrule-2
--  ignore_alpha = 0
--  match:namespace = waybar
-- }

-- layerrule {
--  name = layerrule-3
--  ignore_alpha = 0
--  match:namespace = rofi
-- }

-- layerrule {
--  name = layerrule-4
--  ignore_alpha = 0
--  match:namespace = wofi
-- }
