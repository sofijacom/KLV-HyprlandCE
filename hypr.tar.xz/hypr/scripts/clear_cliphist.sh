#!/bin/bash

rm /home/spot/.cache/cliphist/*
