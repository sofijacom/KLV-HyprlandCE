#!/bin/bash

sudo -HE save2flash  