#!/bin/bash
wlsunset -t 3500 -T 6500 -d 900 -S 07:00 -s 19:00
