#!/usr/bin/env bash

# Простая функция: возвращает один случайный цвет в формате 0xffXXXXXX
random_color() {
    printf "0xff%s" "$(openssl rand -hex 3)"
}

# Генерируем 10 случайных цветов
colors=()
for i in {1..10}; do
    colors+=("$(random_color)")
done

# Формируем строку цветов через пробел
colors_str="${colors[*]}"

# Используем eval — это то, что сейчас требует Hyprland
hyprctl dispatch eval "general:col.active_border ${colors_str} 270deg"
hyprctl dispatch eval "general:col.inactive_border ${colors_str} 270deg"
