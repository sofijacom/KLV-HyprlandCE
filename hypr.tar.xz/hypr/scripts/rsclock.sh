#!/bin/bash

#foot rsclock -S -c -f 5 
kitty --class clock -T clock -e rsclock -S -c -f 5
