#!/bin/bash

exec grim -g "$(slurp)" - | swappy -f -