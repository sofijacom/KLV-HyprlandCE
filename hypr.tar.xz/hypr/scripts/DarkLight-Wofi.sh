#!/bin/bash

set -x
# Define the path
hypr_config_path="$HOME/.config/hypr"

# Define functions for notifying user and updating symlinks
notify_user() {
	notify-send -h string:x-canonical-private-synchronous:sys-notify -u normal "Switching to $1 mode"
}

# Determine the current wallpaper mode by checking a configuration file
if [ "$(cat ~/.wallpaper_mode)" = "light" ]; then
  current_mode="light"
  next_mode="dark"
else
  current_mode="dark"
  next_mode="light"
fi
path_param=$(echo $next_mode | sed 's/.*/\u&/')

notify_user "$next_mode"
#ln -sf "${hypr_config_path}/dunst/styles/dunstrc-${next_mode}" "${hypr_config_path}/dunst/dunstrc"
ln -sf "${hypr_config_path}/wofi/styles/style-${next_mode}.css" "${hypr_config_path}/wofi/style.css"

# Update the configuration file to reflect the new wallpaper mode and current wallpaper
echo "$next_mode" > ~/.wallpaper_mode

sleep 2
exec ~/.config/hypr/scripts/startup &
