#!/bin/bash

foot cmatrix -u 5 -C blue

