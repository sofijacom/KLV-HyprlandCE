#!/bin/bash

exec conky --daemonize --pause=1
