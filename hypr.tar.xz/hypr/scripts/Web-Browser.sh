#!/bin/bash

exec yandex-browser-stable %U
