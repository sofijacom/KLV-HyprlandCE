#!/bin/bash

killall wlsunset
