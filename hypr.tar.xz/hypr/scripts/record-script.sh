#/usr/bin/bash

export clk=1
pgrep wf-recorder || export clk=0
if [ "$clk" -eq "0" ]; then
    fn=/home/spot/Videos/$(date +%F_%T).mp4
    notify-send "wf-recorder" "Starting recording"
    wf-recorder -g "$(slurp)" --file=$fn -c libx264
else
    /usr/bin/kill --signal SIGINT wf-recorder
    notify-send "wf-recorder" "Recording Stopped"
fi
