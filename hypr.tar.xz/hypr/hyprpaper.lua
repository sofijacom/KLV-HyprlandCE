-- ╔══════════════════════════════════════════════════╗
-- ║               configs/hyprpaper.lua              ║
-- ╚══════════════════════════════════════════════════╝

-- Предзагрузка обоев (аналог preload)
hl.exec_cmd("hyprctl dispatch exec 'swaybg -i ~/Pictures/wallpapers/vesturhorn-iceland-priroda.jpg -m fill'")

-- Основной wallpaper (для всех мониторов, если не указано иначе)
hl.exec_cmd("hyprctl keyword wallpaper eDP-1,~/Pictures/wallpapers/vesturhorn-iceland-priroda.jpg")

-- Отключение splash-логотипа Hyprland
hl.config({
    misc = {
        disable_hyprland_logo = true  -- если splash = false — значит, логотип выключен
    }
})

-- IPC (включён по умолчанию, у меня не отключён — значит, оставляем)
-- ipc = on (по умолчанию, явно не нужно писать)
