-- ╔══════════════════════════════════════════════════════════════════════════╗
-- ║                                                                          ║
-- ║     \* ----- 💫 https://github.com/sofijacom/hyprland-void 💫 ---*/      ║
-- ║      \* ........ hyprland.lua made by: Sofiya_&_Linux:~ ........ */      ║
-- ║    _                      _                 _   ____   ___ ____  _____   ║
-- ║   | |__  _   _ _ __  _ __| | __ _ _ __   __| | |___ \ / _ \___ \|  ___|  ║
-- ║   | '_ \| | | | '_ \| '__| |/ _` | '_ \ / _` |   __) | | | |__) | |___   ║
-- ║   | | | | |_| | |_) | |  | | (_| | | | | (_| |  / __/| |_| / __/| |_) |  ║
-- ║   |_| |_|\__, | .__/|_|  |_|\__,_|_| |_|\__,_| |_____|\___/_____|_____/  ║
-- ║          |___/|_|                                                        ║
-- ╚══════════════════════════════════════════════════════════════════════════╝

-- -----------------------------------------------------
-- Autostart
-- -----------------------------------------------------
require("configs.exec")
require("configs.keybinds")
require("configs.monitors")
require("configs.window_rules")
require("configs.environment")
require("configs.autostart")

require("monitors")

hl.device({
    name = "epic-mouse-v1",
    sensitivity = -0.5,
})

hl.curve("slow", { type = "bezier", points = { { 0, 0.85 }, { 0.3, 1 } } })
hl.curve("overshot", { type = "bezier", points = { { 0.7, 0.6 }, { 0.1, 1.1 } } })
hl.curve("bounce", { type = "bezier", points = { { 1, 1.6 }, { 0.1, 0.85 } } })
hl.curve("slingshot", { type = "bezier", points = { { 1, -1 }, { 0.15, 1.25 } } })
hl.curve("myBezier", { type = "bezier", points = { { 0.05, 0.9 }, { 0.1, 1.05 } } })

hl.animation({
    leaf = "windows",
    enabled = true,
    speed = 7,
    bezier = "myBezier",
})
hl.animation({
    leaf = "windowsOut",
    enabled = true,
    speed = 7,
    bezier = "default",
    style = "popin 80%",
})
hl.animation({
    leaf = "border",
    enabled = true,
    speed = 10,
    bezier = "default",
})
hl.animation({
    leaf = "fade",
    enabled = true,
    speed = 7,
    bezier = "default",
})
hl.animation({
    leaf = "workspaces",
    enabled = true,
    speed = 6,
    bezier = "default",
})

local LAPTOP_KB_ENABLED = true
hl.device({
    name = "synps/2-synaptics-touchpad",
    enabled = LAPTOP_KB_ENABLED,
})

hl.window_rule({
    name = "suppress-maximize-events",
    match = {
        class = ".*",
    },
    -- Ignore maximize requests from all apps. You'll probably like this.
    suppress_event = "maximize",
})

hl.window_rule({
    name = "fix-xwayland-drags",
    match = {
        class = "^$",
        title = "^$",
        xwayland = true,
        float = true,
        fullscreen = false,
        pin = false,
    },
    -- Fix some dragging issues with XWayland
    no_focus = true,
})

hl.window_rule({
    name = "move-hyprland-run",
    match = {
        class = "hyprland-run",
    },
    move = "20 monitor_h-120",
    float = true,
})

hl.config({
    general = {
        layout = "dwindle",
        -- See https://wiki.hyprland.org/Configuring/Variables/ for more
        gaps_in = 3,
        gaps_out = 10,
        border_size = 2,
        --one color
        -- col.active_border = rgba(7aa2f7aa)
        -- two colors - gradient
        -- col.active_border = rgb(7287fd) rgb(c6a0f6) rgb(ca9ee6) rgb(cba6f7) 45deg
        -- col.inactive_border = rgb(6c7086)
        col = {
            active_border = { colors = { "rgb(9330AA)", "rgb(47F4A1)", "rgb(2B24DF)" }, angle = 45 },
            inactive_border = "rgba(414868aa)",
        },
        -- col.active_border = rgba(7aa2f7aa) rgba(c4a7e7aa) 45deg
        -- col.inactive_border = rgba(414868aa)
    },
    input = {
        kb_layout = "us, ru",
        kb_variant = "",
        kb_model = "",
        kb_rules = "",
        kb_options = "grp:alt_shift_toggle,terminate:ctrl_alt_bksp",
        follow_mouse = 1,
        sensitivity = 0, -- -1.0 - 1.0, 0 means no modification.
        touchpad = {
            disable_while_typing = 1,
            natural_scroll = 1,
            clickfinger_behavior = 1,
            middle_button_emulation = 1,
            tap_to_click = 1,
            drag_lock = 1,
        },
    },
    gestures = {
        workspace_swipe_distance = 400,
        workspace_swipe_invert = 1,
        workspace_swipe_min_speed_to_force = 30,
        workspace_swipe_cancel_ratio = 0.5,
        workspace_swipe_create_new = 1,
        workspace_swipe_forever = 1,
    },
    -- Example per-device config
    -- See https://wiki.hyprland.org/Configuring/Keywords/#per-device-input-configs for more
    decoration = {
        -- See https://wiki.hyprland.org/Configuring/Variables/ for more
        rounding = 10,
        active_opacity = 1.0,
        inactive_opacity = 1.0,
        fullscreen_opacity = 1.0,
        dim_inactive = true,
        dim_strength = 0.1,
        blur = {
            enabled = true,
            size = 8,
            passes = 2,
            new_optimizations = true,
            vibrancy = 0.1696,
        },
    },
    animations = {
        enabled = 1,
    },
    dwindle = {
        --  pseudotile = true # Master switch for pseudotiling. Enabling is bound to mainMod + P in the keybinds section below
        preserve_split = true, -- You probably want this
    },
    master = {
        new_status = "master",
    },
    binds = {
        workspace_back_and_forth = 1,
        allow_workspace_cycles = 1,
        pass_mouse_when_bound = 0,
    },
    misc = {
        force_default_wallpaper = -1, -- Set to 0 or 1 to disable the anime mascot wallpapers
        disable_hyprland_logo = false, -- If true disables the random hyprland logo / anime girl background. :(
    },
})

